///
/// ps_dimens.dart
/// ----------------------------
/// Developed by Panacea-Soft
/// www.panacea-soft.com
///
class PsDimens {
  // General Spacing
  static const double space1 = 1;
  static const double space2 = 2;
  static const double space4 = 4;
  static const double space6 = 6;
  static const double space8 = 8;
  static const double space10 = 10;
  static const double space12 = 12;
  static const double space14 = 14;
  static const double space16 = 16;
  static const double space18 = 18;
  static const double space20 = 20;
  static const double space24 = 24;
  static const double space28 = 28;
  static const double space32 = 32;
  static const double space36 = 36;
  static const double space40 = 40;
  static const double space44 = 44;
  static const double space48 = 48;
  static const double space52 = 52;
  static const double space56 = 56;
  static const double space60 = 60;
  static const double space64 = 64;
  static const double space68 = 68;
  static const double space72 = 72;
  static const double space76 = 76;
  static const double space80 = 80;
  static const double space84 = 84;
  static const double space88 = 88;
  static const double space92 = 92;
  static const double space96 = 96;
  static const double space100 = 100;
  static const double space104 = 104;
  static const double space120 = 120;
  static const double space140 = 140;
  static const double space160 = 160;
  static const double space180 = 180;
  static const double space200 = 200;
  static const double space220 = 220;
  static const double space240 = 240;
  static const double space260 = 260;
  static const double space280 = 280;
  static const double space300 = 300;
  static const double space312 = 312;
  static const double space320 = 320;
  static const double space328 = 328;
}
