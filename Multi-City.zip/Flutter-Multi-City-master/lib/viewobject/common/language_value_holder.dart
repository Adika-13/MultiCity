import 'package:flutter/material.dart';

class PsLanguageValueHolder {
  PsLanguageValueHolder(
      {@required this.languageCode,
      @required this.countryCode,
      @required this.name});

  String languageCode;
  String countryCode;
  String name;
}
