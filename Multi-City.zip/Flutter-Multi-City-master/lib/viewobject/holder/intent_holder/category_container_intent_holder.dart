import 'package:flutter/material.dart';
import 'package:fluttermulticity/viewobject/city.dart';

class CategoryContainerIntentHolder {
  CategoryContainerIntentHolder(
      {@required this.appBarTitle, @required this.city});
  String appBarTitle;
  City city;
}
