import 'package:flutter/material.dart';

class UserItemIntentHolder {
  const UserItemIntentHolder({
    @required this.userId,
    @required this.status,
    @required this.title,
  });
  final String userId;
  final String status;
  final String title;
}
