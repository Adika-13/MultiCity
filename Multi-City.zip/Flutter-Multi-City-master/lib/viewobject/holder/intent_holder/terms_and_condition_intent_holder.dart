import 'package:flutter/material.dart';

class TermsAndConditionIntentHolder {
  const TermsAndConditionIntentHolder({
    @required this.checkType,
    @required this.description,
  });
  final int checkType;
  final String description;
}
